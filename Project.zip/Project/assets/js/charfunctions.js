
(function () { 
	

		var datapoints = [0, 20, 20, 60, 60, 120, 70, 180, 120, 125, 105, 110, 170];
        var datapoints2 = [0, 10, 30, 25, 80, 20, 10, 60, 40, 125, 105, 110, 170];
        var datapoints3 = [10, 16, 21, 40, 55, 125, 80, 90, 110, 80, 30, 60, 10];
		var config = {
			type: 'line',
			data: {
				labels: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
				datasets: [{
					label: 'Bugs',
					data: datapoints,
					borderColor:'rgba(54, 162, 235, 1)',
					backgroundColor: 'rgba(0, 0, 0, 0)',
					fill: false,
					cubicInterpolationMode: 'monotone'
				}, {
					label: 'History Points',
					data: datapoints2,
					borderColor: 'rgba(255, 99, 132, 0.2)',
					backgroundColor: 'rgba(0, 0, 0, 0)',
					fill: false,
				}, {
					label: 'Taks',
					data: datapoints3,
					borderColor: 'rgba(75, 192, 192, 1)',
					backgroundColor: 'rgba(0, 0, 0, 0)',
					fill: false,
					lineTension: 0
				}]
			},
			options: {
				responsive: true,
				title: {
					display: false,
					//text: 'Awesome char'
				},
				tooltips: {
					mode: 'index'
				},
				scales: {
					xAxes: [{
						display: true,
						scaleLabel: {
							display: true
						}
					}],
					yAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Value'
						},
						ticks: {
							suggestedMin: -10,
							suggestedMax: 200,
						}
					}]
				}
			}
		};
var ctx = document.getElementById('myChart').getContext('2d');
			//window.myLine = new Chart(ctx, config);
var myChart = new Chart(ctx,config);
/* ... */ }());